"""
Base settings for the Annsana project.

Phase 1 scope only (TSD v1.1 §16 / v2.0 §16): users app, auth, base
templates. DRF, SimpleJWT, Celery, Redis, S3 storage, and CORS are
Phase 7 concerns (TSD v2.0) and are intentionally absent here.
"""
from pathlib import Path

import environ

# annsana/annsana/settings/base.py -> project root is three parents up
BASE_DIR = Path(__file__).resolve().parent.parent.parent

env = environ.Env(
    DEBUG=(bool, False),
)
environ.Env.read_env(BASE_DIR / '.env')

# --- Core ---
SECRET_KEY = env('SECRET_KEY')
DEBUG = env('DEBUG')
ALLOWED_HOSTS = env.list('ALLOWED_HOSTS', default=[])

# TSD §5: all PKs are BIGSERIAL.
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# --- Applications ---
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',

    # Third-party
    'crispy_forms',
    'crispy_tailwind',
    'django_htmx',

    # Local apps
    'apps.users',
    'apps.feed',    # Phase 2
    'apps.archive', # Phase 3
    'apps.linking', # Phase 4
    'apps.trust',   # Phase 5
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    # TSD §7: request.htmx availability for all views.
    'django_htmx.middleware.HtmxMiddleware',
]

ROOT_URLCONF = 'annsana.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'apps.trust.context_processors.trust_settings', # Phase 5
            ],
        },
    },
]

WSGI_APPLICATION = 'annsana.wsgi.application'

# --- Database (TSD §3: PostgreSQL 16) ---
DATABASES = {
    'default': env.db('DATABASE_URL'),
}

# --- Password validation ---
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# --- i18n ---
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# --- Static & media (TSD §10) ---
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static']
STATIC_ROOT = BASE_DIR / 'staticfiles'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp']
MAX_UPLOAD_SIZE_MB = 10

# --- Auth (TSD §8) ---
LOGIN_URL = 'users:login'
LOGIN_REDIRECT_URL = 'feed:home'
LOGOUT_REDIRECT_URL = 'home'

SESSION_COOKIE_HTTPONLY = True

# --- Crispy forms (Tailwind pack, TSD §3) ---
CRISPY_ALLOWED_TEMPLATE_PACKS = 'tailwind'
CRISPY_TEMPLATE_PACK = 'tailwind'

# --- Trust Layer constants (TSD §12) ---
# Defined here now even though the trust/archive/linking apps land in later
# phases, so settings stay the single source of truth from day one.
ENTRY_VERIFICATION_THRESHOLD = 3
LINK_VERIFICATION_THRESHOLD = 2
GRIOT_THRESHOLD = 100
