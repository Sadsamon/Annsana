from .base import *  # noqa: F401,F403

DEBUG = True

if not ALLOWED_HOSTS:
    ALLOWED_HOSTS = ['localhost', '127.0.0.1']

# Local filesystem storage for media at dev (S3 cutover is Phase 7).
DEFAULT_FILE_STORAGE = 'django.core.files.storage.FileSystemStorage'
