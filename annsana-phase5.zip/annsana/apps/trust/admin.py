from django.contrib import admin
from .models import Vote


@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ('pk', 'voter', 'entry', 'link', 'created_at')
    list_filter  = ('created_at',)
    search_fields = ('voter__username', 'entry__title')
    raw_id_fields = ('voter', 'entry', 'link')
    readonly_fields = ('created_at',)
