"""
Post-save signal for Vote: updates verification state on the target object
and recalculates the beneficiary's reputation score.

All cross-app imports are deferred inside functions to avoid circular imports
at module-load time (trust ↔ archive ↔ linking ↔ users are mutually dependent).
"""
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import Vote


@receiver(post_save, sender=Vote)
def on_vote_saved(sender, instance, created, **kwargs):
    """Only acts on new votes; editing a vote is not a supported operation."""
    if not created:
        return

    if instance.entry_id:
        _process_entry_vote(instance.entry_id)
    elif instance.link_id:
        _process_link_vote(instance.link_id)


# ---------------------------------------------------------------------------
# Helpers — one per target type
# ---------------------------------------------------------------------------

def _process_entry_vote(entry_pk):
    """Recount votes on entry, set is_verified if threshold met, then recalc rep."""
    from apps.archive.models import ArchiveEntry

    count = Vote.objects.filter(entry_id=entry_pk).count()
    threshold = getattr(settings, 'ENTRY_VERIFICATION_THRESHOLD', 3)

    updates = {'verification_count': count}
    if count >= threshold:
        updates['is_verified'] = True

    ArchiveEntry.objects.filter(pk=entry_pk).update(**updates)

    # Reputation recalc for the entry's author.
    try:
        entry = (
            ArchiveEntry.objects
            .select_related('author__userprofile')
            .get(pk=entry_pk)
        )
        if entry.author_id:
            entry.author.userprofile.recalculate_reputation()
    except Exception:
        pass  # Never let a reputation hiccup break a vote.


def _process_link_vote(link_pk):
    """Recount votes on link, set is_verified if threshold met, then recalc rep."""
    from apps.linking.models import PostArchiveLink

    count = Vote.objects.filter(link_id=link_pk).count()
    threshold = getattr(settings, 'LINK_VERIFICATION_THRESHOLD', 2)

    updates = {'verification_count': count}
    if count >= threshold:
        updates['is_verified'] = True

    PostArchiveLink.objects.filter(pk=link_pk).update(**updates)

    # Reputation recalc for the link's creator.
    try:
        link = (
            PostArchiveLink.objects
            .select_related('created_by__userprofile')
            .get(pk=link_pk)
        )
        if link.created_by_id:
            link.created_by.userprofile.recalculate_reputation()
    except Exception:
        pass
