"""
Trust Layer — Phase 5.

Vote is the atomic unit of Griot verification. One Griot, one vote per target.
Exactly one of (entry, link) must be set; the DB enforces this with a
CheckConstraint so even out-of-band writes cannot violate it.

Thresholds (TSD §12):
  ENTRY_VERIFICATION_THRESHOLD = 3   (settings)
  LINK_VERIFICATION_THRESHOLD  = 2   (settings)
  GRIOT_THRESHOLD              = 100 (settings)
"""
from django.conf import settings
from django.db import models
from django.db.models import CheckConstraint, Q, UniqueConstraint


class Vote(models.Model):
    voter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='votes_cast',
    )
    # Exactly one of these two FKs must be non-null (enforced by CheckConstraint).
    entry = models.ForeignKey(
        'archive.ArchiveEntry',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='votes',
    )
    link = models.ForeignKey(
        'linking.PostArchiveLink',
        on_delete=models.CASCADE,
        null=True, blank=True,
        related_name='votes',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'trust_vote'
        constraints = [
            # Structural: vote must target exactly one object.
            CheckConstraint(
                check=(
                    Q(entry__isnull=False, link__isnull=True) |
                    Q(entry__isnull=True,  link__isnull=False)
                ),
                name='trust_vote_exactly_one_target',
            ),
            # Behavioural: one Griot, one vote per entry.
            UniqueConstraint(
                fields=['voter', 'entry'],
                condition=Q(entry__isnull=False),
                name='trust_vote_unique_voter_entry',
            ),
            # Behavioural: one Griot, one vote per link.
            UniqueConstraint(
                fields=['voter', 'link'],
                condition=Q(link__isnull=False),
                name='trust_vote_unique_voter_link',
            ),
        ]
        ordering = ['-created_at']

    def __str__(self):
        target = (
            f'entry:{self.entry_id}' if self.entry_id else f'link:{self.link_id}'
        )
        return f'Vote by {self.voter.username} on {target}'
