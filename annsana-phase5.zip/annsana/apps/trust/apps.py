from django.apps import AppConfig


class TrustConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.trust'
    label = 'trust'
    verbose_name = 'Trust'

    def ready(self):
        import apps.trust.signals  # noqa: F401 — registers post_save on Vote
