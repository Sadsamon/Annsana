"""
Makes trust threshold constants available in every template, so partials
rendered via HTMX (where view context isn't inherited) can still display
"X / 3 verifications needed" without an explicit view-level pass.
"""
from django.conf import settings


def trust_settings(request):
    return {
        'ENTRY_VERIFICATION_THRESHOLD': getattr(settings, 'ENTRY_VERIFICATION_THRESHOLD', 3),
        'LINK_VERIFICATION_THRESHOLD':  getattr(settings, 'LINK_VERIFICATION_THRESHOLD',  2),
        'GRIOT_THRESHOLD':              getattr(settings, 'GRIOT_THRESHOLD',             100),
    }
