"""
Trust views — Phase 5.

vote_entry  : Griot-only, verifies an ArchiveEntry.
vote_link   : Griot-only, verifies a PostArchiveLink.

Both are POST-only and HTMX-aware:
  - vote_entry  returns _entry_verification.html (outerHTML swap on #entry-verification)
  - vote_link   redirects to the appropriate linking partial; HTMX follows
                the 302 as a GET and renders the partial into its target div.

Self-voting is silently ignored (returns the current state unchanged).
get_or_create prevents double-voting at the view level; UniqueConstraint
guards at the DB level.
"""
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from apps.archive.models import ArchiveEntry
from apps.linking.models import PostArchiveLink
from apps.users.decorators import griot_required

from .models import Vote


# ---------------------------------------------------------------------------
# Vote views
# ---------------------------------------------------------------------------

@griot_required
def vote_entry(request, slug):
    if request.method != 'POST':
        return redirect('archive:entry_detail', slug=slug)

    entry = get_object_or_404(
        ArchiveEntry.objects.select_related('author'),
        slug=slug,
    )

    if entry.author != request.user:
        Vote.objects.get_or_create(voter=request.user, entry=entry, link=None)
        entry.refresh_from_db()  # pick up signal-updated verification_count / is_verified

    if request.htmx:
        return _entry_verification_response(request, entry)
    return redirect('archive:entry_detail', slug=slug)


@griot_required
def vote_link(request, pk):
    if request.method != 'POST':
        return redirect('feed:home')

    link = get_object_or_404(
        PostArchiveLink.objects.select_related('post', 'entry', 'created_by'),
        pk=pk,
    )
    source = request.POST.get('source', 'post')

    if link.created_by != request.user:
        Vote.objects.get_or_create(voter=request.user, link=link, entry=None)
        link.refresh_from_db()

    if request.htmx:
        # Redirect to the linking partial; HTMX follows the 302 GET and
        # renders the refreshed partial (now including "You verified") into
        # the caller's hx-target div.
        if source == 'entry':
            return redirect(
                'linking:entry_links_partial',
                entry_slug=link.entry.slug,
            )
        return redirect('linking:post_links_partial', post_pk=link.post_id)

    if source == 'entry':
        return redirect('archive:entry_detail', slug=link.entry.slug)
    return redirect('feed:post_detail', pk=link.post_id)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _entry_verification_response(request, entry):
    has_voted = (
        Vote.objects.filter(voter=request.user, entry=entry).exists()
        if request.user.is_authenticated else False
    )
    return render(request, 'trust/_entry_verification.html', {
        'entry': entry,
        'has_voted': has_voted,
    })
