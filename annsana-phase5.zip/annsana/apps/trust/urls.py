from django.urls import path
from . import views

app_name = 'trust'

urlpatterns = [
    path('entry/<slug:slug>/vote/', views.vote_entry, name='vote_entry'),
    path('link/<int:pk>/vote/',     views.vote_link,  name='vote_link'),
]
