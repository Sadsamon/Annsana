from django.conf import settings
from django.db import models
from django.utils.text import slugify


class ArchiveEntry(models.Model):
    """
    Wiki-style cultural knowledge article (TSD §5.3: archive_archiveentry).

    Only Griots (userprofile.is_griot=True) or staff may create entries.
    is_verified and verification_count are Trust Layer fields (Phase 5);
    they exist here from day one so the schema is stable.

    on_delete=PROTECT for author so deleting a user account doesn't
    silently wipe curated archive content -- admin must reassign first.
    """
    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, max_length=280)
    body = models.TextField()
    category = models.ForeignKey(
        'feed.Category',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='archive_entries',
    )
    author = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.PROTECT,
        related_name='archive_entries',
    )
    is_verified = models.BooleanField(default=False)
    verification_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'archive_archiveentry'
        verbose_name = 'archive entry'
        verbose_name_plural = 'archive entries'
        ordering = ['-created_at']

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.title)[:270]
            candidate = base
            n = 1
            while ArchiveEntry.objects.filter(slug=candidate).exclude(pk=self.pk).exists():
                candidate = f'{base}-{n}'
                n += 1
            self.slug = candidate
        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    def get_schema_type(self):
        """Return 'recipe', 'guideline', or 'none'."""
        if hasattr(self, 'recipe'):
            return 'recipe'
        if hasattr(self, 'guideline'):
            return 'guideline'
        return 'none'


class Recipe(models.Model):
    """
    Structured recipe schema attached to one ArchiveEntry (TSD §5.3).

    ingredients and steps are stored as JSON arrays of strings.
    The form converts textarea lines ↔ JSON lists on the way in/out.
    """
    entry = models.OneToOneField(
        ArchiveEntry,
        on_delete=models.CASCADE,
        related_name='recipe',
    )
    ingredients = models.JSONField()
    steps = models.JSONField()
    prep_time_minutes = models.IntegerField(null=True, blank=True)
    cook_time_minutes = models.IntegerField(null=True, blank=True)
    serves = models.IntegerField(null=True, blank=True)

    class Meta:
        db_table = 'archive_recipe'

    def __str__(self):
        return f'Recipe for "{self.entry.title}"'


class Guideline(models.Model):
    """
    Structured guideline schema (how-to / ceremonial steps) for one
    ArchiveEntry (TSD §5.3).

    steps and materials are JSON arrays of strings.
    """
    entry = models.OneToOneField(
        ArchiveEntry,
        on_delete=models.CASCADE,
        related_name='guideline',
    )
    steps = models.JSONField()
    materials = models.JSONField(null=True, blank=True)
    duration_notes = models.TextField(null=True, blank=True)

    class Meta:
        db_table = 'archive_guideline'

    def __str__(self):
        return f'Guideline for "{self.entry.title}"'
