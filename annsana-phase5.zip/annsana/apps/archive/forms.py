"""
Archive forms.

JSON fields (ingredients, steps, materials) are edited as plain textarea
with one item per line and converted to/from Python lists by the form's
clean methods. This keeps the UX simple without requiring a JS-heavy
structured editor at this phase.
"""
from django import forms

from .models import ArchiveEntry, Guideline, Recipe

SCHEMA_CHOICES = [
    ('none',      'General entry'),
    ('recipe',    'Recipe'),
    ('guideline', 'Guideline / How-to'),
]


def _lines_to_list(raw):
    """Strip blank lines; return list of stripped strings."""
    return [line.strip() for line in raw.splitlines() if line.strip()]


def _list_to_text(lst):
    """Convert a JSON list back to newline-separated text for the textarea."""
    if isinstance(lst, list):
        return '\n'.join(str(item) for item in lst)
    return ''


class ArchiveEntryForm(forms.ModelForm):
    schema_type = forms.ChoiceField(
        choices=SCHEMA_CHOICES,
        initial='none',
        widget=forms.Select(attrs={
            'hx-get':     '',   # set by template via {% url 'archive:schema_fields' %}
            'hx-target':  '#schema-fields',
            'hx-trigger': 'change',
            # hx-include not needed: the select's own name is sent automatically
        }),
        label='Content schema',
        help_text='Choose whether this entry includes a Recipe or How-to Guideline.',
    )

    class Meta:
        model = ArchiveEntry
        fields = ('title', 'body', 'category', 'schema_type')
        widgets = {
            'title': forms.TextInput(attrs={'placeholder': 'e.g. The History of Sadza'}),
            'body': forms.Textarea(attrs={
                'rows': 10,
                'placeholder': 'Write the encyclopaedic content here…',
            }),
        }

    def __init__(self, *args, schema_type='none', **kwargs):
        super().__init__(*args, **kwargs)
        # schema_type is not a model field; initialise from kwarg or POST data.
        self.fields['schema_type'].initial = schema_type


class RecipeInlineForm(forms.ModelForm):
    """
    Inline form for the Recipe sub-schema.
    JSON lists are edited as newline-separated textarea values.
    """
    ingredients = forms.CharField(
        widget=forms.Textarea(attrs={
            'rows': 6,
            'placeholder': '2 cups maize flour\n1 cup water\nSalt to taste',
        }),
        help_text='One ingredient per line.',
    )
    steps = forms.CharField(
        widget=forms.Textarea(attrs={
            'rows': 6,
            'placeholder': 'Boil water in a heavy pot.\nAdd maize flour gradually…',
        }),
        help_text='One step per line.',
    )

    class Meta:
        model = Recipe
        exclude = ('entry',)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # When editing an existing Recipe, convert JSON → textarea text.
        inst = kwargs.get('instance')
        if inst and inst.pk:
            self.fields['ingredients'].initial = _list_to_text(inst.ingredients)
            self.fields['steps'].initial = _list_to_text(inst.steps)

    def clean_ingredients(self):
        items = _lines_to_list(self.cleaned_data['ingredients'])
        if not items:
            raise forms.ValidationError('At least one ingredient is required.')
        return items

    def clean_steps(self):
        items = _lines_to_list(self.cleaned_data['steps'])
        if not items:
            raise forms.ValidationError('At least one step is required.')
        return items


class GuidelineInlineForm(forms.ModelForm):
    """
    Inline form for the Guideline sub-schema.
    JSON lists are edited as newline-separated textarea values.
    """
    steps = forms.CharField(
        widget=forms.Textarea(attrs={
            'rows': 6,
            'placeholder': 'Prepare the ceremonial cloth.\nArrange elders in a circle…',
        }),
        help_text='One step per line.',
    )
    materials = forms.CharField(
        required=False,
        widget=forms.Textarea(attrs={
            'rows': 4,
            'placeholder': 'Kente cloth\nShea butter\nKola nuts',
        }),
        help_text='One material per line (optional).',
    )

    class Meta:
        model = Guideline
        exclude = ('entry',)
        widgets = {
            'duration_notes': forms.Textarea(attrs={
                'rows': 2,
                'placeholder': 'e.g. The full ceremony lasts 3 days.',
            }),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        inst = kwargs.get('instance')
        if inst and inst.pk:
            self.fields['steps'].initial = _list_to_text(inst.steps)
            if inst.materials:
                self.fields['materials'].initial = _list_to_text(inst.materials)

    def clean_steps(self):
        items = _lines_to_list(self.cleaned_data['steps'])
        if not items:
            raise forms.ValidationError('At least one step is required.')
        return items

    def clean_materials(self):
        raw = self.cleaned_data.get('materials', '')
        items = _lines_to_list(raw)
        return items if items else None
