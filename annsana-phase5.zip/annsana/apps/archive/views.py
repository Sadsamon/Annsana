"""
Archive views — Phase 3.

Access model (TSD §13 / §12):
  - List + Detail : public (AllowAny), honouring the educational mission.
  - Create        : Griot or staff only (@griot_required).
  - Edit          : Original author (if still Griot) or staff/superuser.

HTMX usage:
  - schema_fields_partial: swaps the schema-specific form section when the
    user changes the "Content schema" select on the create/edit form.
"""
from django.contrib import messages
from django.core.exceptions import PermissionDenied
from django.core.paginator import Paginator
from django.http import HttpResponse, HttpResponseBadRequest
from django.shortcuts import get_object_or_404, redirect, render

from apps.users.decorators import griot_required

from .forms import ArchiveEntryForm, GuidelineInlineForm, RecipeInlineForm
from .models import ArchiveEntry, Guideline, Recipe

ENTRIES_PER_PAGE = 15


# ---------------------------------------------------------------------------
# Public views
# ---------------------------------------------------------------------------

def archive_list(request):
    qs = (
        ArchiveEntry.objects
        .select_related('author', 'author__userprofile', 'category')
        .all()
    )

    # Optional category filter
    category_slug = request.GET.get('category')
    if category_slug:
        qs = qs.filter(category__slug=category_slug)

    paginator = Paginator(qs, ENTRIES_PER_PAGE)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    # Pass the full category list so the sidebar can render without a
    # template-level split filter (which Django doesn't have built-in).
    from apps.feed.models import Category
    categories = Category.objects.all().order_by('name')

    return render(request, 'archive/archive_list.html', {
        'page_obj': page_obj,
        'active_category': category_slug,
        'categories': categories,
    })


def entry_detail(request, slug):
    entry = get_object_or_404(
        ArchiveEntry.objects
        .select_related('author', 'author__userprofile', 'category')
        .prefetch_related('recipe', 'guideline'),
        slug=slug,
    )
    schema_type = entry.get_schema_type()
    # Phase 4: linking context for non-JS fallback.
    from apps.linking.forms import LinkFromEntryForm
    from apps.linking.models import PostArchiveLink
    post_links = (
        PostArchiveLink.objects
        .filter(entry=entry)
        .select_related('post', 'post__user', 'post__category', 'created_by')
        .order_by('-created_at')
    )
    link_form = LinkFromEntryForm(initial={'entry_pk': entry.pk})
    link_form.fields['entry_pk'].initial = entry.pk

    # Phase 5: has the current Griot already voted on this entry?
    user_has_voted = False
    if request.user.is_authenticated:
        try:
            from apps.trust.models import Vote
            user_has_voted = Vote.objects.filter(
                voter=request.user, entry=entry
            ).exists()
        except Exception:
            pass

    return render(request, 'archive/entry_detail.html', {
        'entry': entry,
        'schema_type': schema_type,
        'post_links': post_links,
        'link_from_entry_form': link_form,
        'user_has_voted': user_has_voted,
    })


# ---------------------------------------------------------------------------
# Griot-only write views
# ---------------------------------------------------------------------------

@griot_required
def entry_create(request):
    schema_type = request.POST.get('schema_type', 'none')

    if request.method == 'POST':
        entry_form = ArchiveEntryForm(request.POST, schema_type=schema_type)
        recipe_form = RecipeInlineForm(request.POST) if schema_type == 'recipe' else RecipeInlineForm()
        guideline_form = GuidelineInlineForm(request.POST) if schema_type == 'guideline' else GuidelineInlineForm()

        schema_form = _pick_schema_form(schema_type, recipe_form, guideline_form)
        entry_valid = entry_form.is_valid()
        schema_valid = schema_form.is_valid() if schema_form else True

        if entry_valid and schema_valid:
            entry = entry_form.save(commit=False)
            entry.author = request.user
            entry.save()

            if schema_form:
                obj = schema_form.save(commit=False)
                obj.entry = entry
                obj.save()

            messages.success(request, f'"{entry.title}" has been published to the Archive.')
            return redirect('archive:entry_detail', slug=entry.slug)
    else:
        entry_form = ArchiveEntryForm(schema_type='none')
        recipe_form = RecipeInlineForm()
        guideline_form = GuidelineInlineForm()
        schema_type = 'none'

    return render(request, 'archive/entry_create.html', {
        'entry_form': entry_form,
        'recipe_form': recipe_form,
        'guideline_form': guideline_form,
        'schema_type': schema_type,
        'action': 'create',
    })


@griot_required
def entry_edit(request, slug):
    entry = get_object_or_404(ArchiveEntry, slug=slug)

    # Only the original author (if still a Griot) or staff may edit.
    if not (request.user.is_staff or request.user.is_superuser or entry.author == request.user):
        raise PermissionDenied

    existing_schema = entry.get_schema_type()
    recipe_inst = getattr(entry, 'recipe', None)
    guideline_inst = getattr(entry, 'guideline', None)

    schema_type = request.POST.get('schema_type', existing_schema)

    if request.method == 'POST':
        entry_form = ArchiveEntryForm(request.POST, instance=entry, schema_type=schema_type)
        recipe_form = RecipeInlineForm(request.POST, instance=recipe_inst) if schema_type == 'recipe' else RecipeInlineForm()
        guideline_form = GuidelineInlineForm(request.POST, instance=guideline_inst) if schema_type == 'guideline' else GuidelineInlineForm()

        schema_form = _pick_schema_form(schema_type, recipe_form, guideline_form)
        entry_valid = entry_form.is_valid()
        schema_valid = schema_form.is_valid() if schema_form else True

        if entry_valid and schema_valid:
            entry = entry_form.save()

            # Handle schema type change: delete old schema if switching types.
            if schema_type != existing_schema:
                if existing_schema == 'recipe' and recipe_inst:
                    recipe_inst.delete()
                elif existing_schema == 'guideline' and guideline_inst:
                    guideline_inst.delete()

            if schema_form:
                # schema_form instance is already set (recipe_inst / guideline_inst)
                # or None (creating fresh).
                obj = schema_form.save(commit=False)
                obj.entry = entry
                obj.save()
            elif schema_type == 'none':
                # User removed the schema; already deleted above if it existed.
                pass

            messages.success(request, f'"{entry.title}" updated.')
            return redirect('archive:entry_detail', slug=entry.slug)
    else:
        entry_form = ArchiveEntryForm(instance=entry, schema_type=existing_schema)
        recipe_form = RecipeInlineForm(instance=recipe_inst) if recipe_inst else RecipeInlineForm()
        guideline_form = GuidelineInlineForm(instance=guideline_inst) if guideline_inst else GuidelineInlineForm()
        schema_type = existing_schema

    return render(request, 'archive/entry_create.html', {
        'entry_form': entry_form,
        'recipe_form': recipe_form,
        'guideline_form': guideline_form,
        'schema_type': schema_type,
        'action': 'edit',
        'entry': entry,
    })


# ---------------------------------------------------------------------------
# HTMX partial
# ---------------------------------------------------------------------------

def schema_fields_partial(request):
    """
    Return the schema-specific form fields partial based on ?schema_type=.
    Responds only to HTMX requests; returns an empty 200 for 'none'.
    """
    if not request.htmx:
        return HttpResponseBadRequest('HTMX requests only.')

    schema_type = request.GET.get('schema_type', 'none')

    if schema_type == 'recipe':
        return render(request, 'archive/_recipe_fields.html', {
            'recipe_form': RecipeInlineForm(),
        })
    if schema_type == 'guideline':
        return render(request, 'archive/_guideline_fields.html', {
            'guideline_form': GuidelineInlineForm(),
        })

    return HttpResponse('')  # 'none' — clears the schema fields div


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _pick_schema_form(schema_type, recipe_form, guideline_form):
    """Return the active schema form or None for 'none'."""
    if schema_type == 'recipe':
        return recipe_form
    if schema_type == 'guideline':
        return guideline_form
    return None
