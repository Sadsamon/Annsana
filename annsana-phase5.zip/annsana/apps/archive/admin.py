from django.contrib import admin

from .models import ArchiveEntry, Guideline, Recipe


class RecipeInline(admin.StackedInline):
    model = Recipe
    can_delete = True
    extra = 0


class GuidelineInline(admin.StackedInline):
    model = Guideline
    can_delete = True
    extra = 0


@admin.register(ArchiveEntry)
class ArchiveEntryAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'schema_type', 'is_verified',
                    'verification_count', 'created_at')
    list_filter = ('is_verified', 'category', 'created_at')
    search_fields = ('title', 'body', 'author__username')
    prepopulated_fields = {'slug': ('title',)}
    raw_id_fields = ('author',)
    readonly_fields = ('created_at', 'updated_at', 'verification_count')
    inlines = (RecipeInline, GuidelineInline)

    @admin.display(description='Schema')
    def schema_type(self, obj):
        return obj.get_schema_type()
