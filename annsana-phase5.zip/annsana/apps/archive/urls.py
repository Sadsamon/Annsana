from django.urls import path

from . import views

app_name = 'archive'

urlpatterns = [
    # Literals before slug capture to avoid 'create' / 'schema-fields'
    # being swallowed as slugs.
    path('',                    views.archive_list,        name='list'),
    path('create/',             views.entry_create,        name='entry_create'),
    path('schema-fields/',      views.schema_fields_partial, name='schema_fields'),
    path('<slug:slug>/',        views.entry_detail,        name='entry_detail'),
    path('<slug:slug>/edit/',   views.entry_edit,          name='entry_edit'),
]
