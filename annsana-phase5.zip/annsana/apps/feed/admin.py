from django.contrib import admin

from .models import Category, Hashtag, Post


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'created_at')
    prepopulated_fields = {'slug': ('name',)}
    search_fields = ('name',)


@admin.register(Hashtag)
class HashtagAdmin(admin.ModelAdmin):
    list_display = ('name', 'created_at')
    search_fields = ('name',)


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('pk', 'user', 'category', 'has_image', 'created_at')
    list_filter = ('category', 'created_at')
    search_fields = ('caption', 'user__username')
    raw_id_fields = ('user',)
    filter_horizontal = ('hashtags',)
    readonly_fields = ('created_at', 'updated_at')

    @admin.display(boolean=True, description='Image')
    def has_image(self, obj):
        return bool(obj.image)
