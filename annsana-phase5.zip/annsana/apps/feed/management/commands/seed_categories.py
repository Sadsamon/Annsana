"""
Idempotent category seeder.

Usage:  python manage.py seed_categories

The same data is also applied automatically by migration
0002_seed_categories, so this command is mainly useful for:
  - resetting dev fixtures after a database wipe without re-migrating
  - CI environments that apply migrations separately from fixtures
"""
from django.core.management.base import BaseCommand

from apps.feed.models import Category

CATEGORIES = [
    ('Food',         'food',         'Traditional dishes, recipes, and food culture.'),
    ('Attire',       'attire',       'Clothing, textiles, and traditional dress.'),
    ('Rituals',      'rituals',      'Ceremonies, rites of passage, and spiritual practices.'),
    ('Music',        'music',        'Traditional instruments, songs, and musical traditions.'),
    ('Language',     'language',     'Proverbs, oral literature, scripts, and dialects.'),
    ('Crafts',       'crafts',       'Handmade objects, artisanry, and material culture.'),
    ('Architecture', 'architecture', 'Buildings, settlements, and built environment.'),
    ('Ceremonies',   'ceremonies',   'Community gatherings, festivals, and celebrations.'),
]


class Command(BaseCommand):
    help = 'Seed the database with the eight canonical cultural categories.'

    def handle(self, *args, **options):
        created_count = 0
        for name, slug, description in CATEGORIES:
            _, created = Category.objects.get_or_create(
                slug=slug,
                defaults={'name': name, 'description': description},
            )
            if created:
                created_count += 1
                self.stdout.write(self.style.SUCCESS(f'  Created: {name}'))
            else:
                self.stdout.write(f'  Already exists: {name}')

        self.stdout.write(
            self.style.SUCCESS(
                f'\nDone. {created_count} new categories created, '
                f'{len(CATEGORIES) - created_count} already present.'
            )
        )
