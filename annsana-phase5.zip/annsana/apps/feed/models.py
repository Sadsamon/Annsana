from django.conf import settings
from django.db import models
from django.utils.text import slugify


class Category(models.Model):
    """
    Curated taxonomy for posts (TSD §5.2: feed_category).

    Seeded via 0002_seed_categories data migration with the eight
    TSD-specified cultural domains. Griots and admins may extend it.
    """
    name = models.CharField(max_length=100)
    slug = models.SlugField(unique=True)
    description = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'feed_category'
        verbose_name_plural = 'categories'
        ordering = ['name']

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    def __str__(self):
        return self.name


class Hashtag(models.Model):
    """
    Normalised hashtag (TSD §5.2: feed_hashtag).

    Stored lowercase, without the '#' character. Created on-demand via
    get_or_create when a post is submitted.
    """
    name = models.CharField(max_length=50, unique=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'feed_hashtag'
        ordering = ['name']

    def __str__(self):
        return f'#{self.name}'


class Post(models.Model):
    """
    User-generated cultural content (TSD §5.2: feed_post).

    video is declared in the schema but excluded from the Phase 2 form
    intentionally -- the upload UI for video arrives in a later iteration.
    Image processing is synchronous Pillow (Phase 2); Celery replaces it
    in Phase 7.
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='posts',
    )
    caption = models.TextField()
    image = models.ImageField(
        upload_to='posts/%Y/%m/',
        null=True,
        blank=True,
    )
    # Video field present per TSD schema; not exposed in Phase 2 form.
    video = models.FileField(
        upload_to='posts/videos/%Y/%m/',
        null=True,
        blank=True,
    )
    category = models.ForeignKey(
        Category,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='posts',
    )
    hashtags = models.ManyToManyField(
        Hashtag,
        blank=True,
        related_name='posts',
    )
    geolocation = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        db_table = 'feed_post'
        ordering = ['-created_at']

    def __str__(self):
        return f'Post #{self.pk} by {self.user.username}'
