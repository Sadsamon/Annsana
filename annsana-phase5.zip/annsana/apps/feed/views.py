"""
Feed views — Phase 2.

HTMX infinite scroll pattern:
  - Regular request  → render full feed/home.html (contains _post_list.html)
  - HTMX request     → render feed/_post_list.html partial only
  The _post_list.html partial ends with a sentinel <div> that triggers
  the next-page fetch when it enters the viewport (hx-trigger="revealed").
"""
import os

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, redirect, render

from PIL import Image

from .forms import PostForm
from .models import Hashtag, Post

POSTS_PER_PAGE = 12


def feed_home(request):
    posts = (
        Post.objects
        .select_related('user', 'user__userprofile', 'category')
        .prefetch_related('hashtags')
        .all()
    )
    paginator = Paginator(posts, POSTS_PER_PAGE)
    page_obj = paginator.get_page(request.GET.get('page', 1))

    # HTMX infinite-scroll requests get only the list partial.
    if request.htmx:
        return render(request, 'feed/_post_list.html', {'page_obj': page_obj})

    return render(request, 'feed/home.html', {'page_obj': page_obj})


@login_required
def post_create(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            post = form.save(commit=False)
            post.user = request.user
            post.save()

            # Resolve hashtags and attach (get_or_create, normalised lowercase).
            hashtag_names = form.parse_hashtags()
            if hashtag_names:
                objs = [
                    Hashtag.objects.get_or_create(name=name)[0]
                    for name in hashtag_names
                ]
                post.hashtags.set(objs)

            # Synchronous image processing (Phase 2).
            # Phase 7 replaces this call with core.tasks.process_image_field.delay().
            if post.image:
                _process_image(post)

            messages.success(request, 'Your post has been shared.')
            return redirect('feed:post_detail', pk=post.pk)
    else:
        form = PostForm()

    return render(request, 'feed/post_create.html', {'form': form})


def post_detail(request, pk):
    post = get_object_or_404(
        Post.objects
        .select_related('user', 'user__userprofile', 'category')
        .prefetch_related('hashtags'),
        pk=pk,
    )
    # Phase 4: provide linking context for the non-JS (server-side) fallback.
    # The HTMX path in the template loads the partial via hx-trigger="load",
    # but if JS is off the include renders from this context instead.
    from apps.linking.forms import LinkFromPostForm
    from apps.linking.models import PostArchiveLink
    archive_links = (
        PostArchiveLink.objects
        .filter(post=post)
        .select_related('entry', 'entry__category', 'created_by')
        .order_by('-created_at')
    )
    link_form = LinkFromPostForm(initial={'post_pk': post.pk})
    link_form.fields['post_pk'].initial = post.pk
    return render(request, 'feed/post_detail.html', {
        'post': post,
        'archive_links': archive_links,
        'link_from_post_form': link_form,
    })


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _process_image(post):
    """
    Resize oversized images to max 1920 px on the longest side and
    re-save as JPEG at quality=85 to keep media storage sane.

    Operates on the already-persisted file (image.path) so no model
    re-save is needed.  Failures are swallowed -- a raw upload is always
    better than a broken post.

    Phase 7: replace body with core.tasks.process_image_field.delay()
    and remove this function entirely.
    """
    try:
        path = post.image.path
        img = Image.open(path)

        # Flatten alpha / palette so JPEG save never raises
        if img.mode in ('RGBA', 'P', 'LA'):
            background = Image.new('RGB', img.size, (255, 255, 255))
            if img.mode == 'P':
                img = img.convert('RGBA')
            background.paste(img, mask=img.split()[-1] if img.mode in ('RGBA', 'LA') else None)
            img = background
        elif img.mode != 'RGB':
            img = img.convert('RGB')

        # Resize if either dimension exceeds 1920 px
        img.thumbnail((1920, 1920), Image.LANCZOS)

        # Normalise extension to .jpg
        base = os.path.splitext(path)[0]
        new_path = base + '.jpg'
        img.save(new_path, format='JPEG', quality=85, optimize=True)

        if new_path != path:
            os.remove(path)
            # Update the ImageField name stored in the DB
            rel = os.path.relpath(new_path, post.image.storage.location)
            post.image.name = rel
            post.save(update_fields=['image'])

    except Exception:
        # Never let image processing break the user's post.
        pass
