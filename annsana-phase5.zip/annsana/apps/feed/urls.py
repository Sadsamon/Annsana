from django.urls import path

from . import views

app_name = 'feed'

urlpatterns = [
    path('', views.feed_home, name='home'),
    path('post/create/', views.post_create, name='post_create'),
    path('post/<int:pk>/', views.post_detail, name='post_detail'),
]
