from django import forms

from .models import Category, Post
from .validators import validate_post_image


class PostForm(forms.ModelForm):
    """
    Post creation / editing form.

    hashtags_input: free-text field (space or comma separated, # optional).
    Parsed into Hashtag objects in the view after save().

    Video upload is deliberately excluded from Phase 2 -- the field
    exists on the model but the upload UI lands in a future iteration.
    """
    hashtags_input = forms.CharField(
        required=False,
        max_length=255,
        label='Hashtags',
        help_text='Space or comma-separated. Example: food culture yoruba',
        widget=forms.TextInput(attrs={'placeholder': 'food culture yoruba …'}),
    )

    class Meta:
        model = Post
        fields = ('caption', 'image', 'category', 'geolocation')
        widgets = {
            'caption': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Share something cultural…'}),
            'geolocation': forms.TextInput(attrs={'placeholder': 'e.g. Lagos, Nigeria'}),
        }

    def clean_image(self):
        image = self.cleaned_data.get('image')
        if image:
            validate_post_image(image)
        return image

    def clean(self):
        cleaned = super().clean()
        if not cleaned.get('caption') and not cleaned.get('image'):
            raise forms.ValidationError(
                'A post must have at least a caption or an image.'
            )
        return cleaned

    def parse_hashtags(self):
        """
        Return a list of normalised hashtag name strings from hashtags_input.
        Called by the view after form.is_valid().
        """
        raw = self.cleaned_data.get('hashtags_input', '')
        names = [
            token.lstrip('#').lower().strip()
            for token in raw.replace(',', ' ').split()
        ]
        # Deduplicate, drop empties, cap at 10 per TSD §4.
        seen = set()
        result = []
        for name in names:
            if name and name not in seen and len(name) <= 50:
                seen.add(name)
                result.append(name)
                if len(result) >= 10:
                    break
        return result
