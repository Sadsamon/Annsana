"""
Image validation utilities for the feed app.

Processing (resize/compress) is intentionally separate from validation
and lives in views.py for Phase 2. Phase 7 moves processing to
core.tasks.process_image_field (Celery).
"""
from django.conf import settings
from django.core.exceptions import ValidationError
from PIL import Image, UnidentifiedImageError

ALLOWED_PILLOW_FORMATS = {'JPEG', 'PNG', 'WEBP'}


def validate_post_image(image):
    """
    Django field validator: size + genuine image type check.

    Designed to be used as a model-level validator so it applies to
    both the form and any programmatic creation path.
    """
    # --- Size ---
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    if image.size > max_bytes:
        raise ValidationError(
            f'Image exceeds the {settings.MAX_UPLOAD_SIZE_MB} MB limit '
            f'({image.size / 1024 / 1024:.1f} MB uploaded).'
        )

    # --- Genuine image (not just an extension check) ---
    try:
        image.seek(0)
        img = Image.open(image)
        img.verify()          # Detects truncated / corrupted files
    except (UnidentifiedImageError, Exception):
        raise ValidationError('The uploaded file is not a valid image.')

    # After verify() the file pointer is in an indeterminate state; re-open.
    image.seek(0)
    try:
        img = Image.open(image)
        fmt = img.format
    except Exception:
        raise ValidationError('Could not read image format.')

    if fmt not in ALLOWED_PILLOW_FORMATS:
        raise ValidationError(
            f'Format "{fmt}" is not supported. '
            f'Please upload a JPEG, PNG, or WebP file.'
        )

    image.seek(0)
