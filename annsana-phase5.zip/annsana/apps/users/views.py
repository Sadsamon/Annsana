from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import get_object_or_404, redirect, render

from .forms import ProfileEditForm, RegisterForm


def register(request):
    if request.user.is_authenticated:
        return redirect('home')

    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Welcome to Annsana — your account is ready.')
            return redirect('users:profile_detail', username=user.username)
    else:
        form = RegisterForm()

    return render(request, 'users/register.html', {'form': form})


def profile_detail(request, username):
    profile_user = get_object_or_404(User, username=username)
    return render(request, 'users/profile.html', {
        'profile_user': profile_user,
        'profile': profile_user.userprofile,
    })


@login_required
def profile_edit(request):
    profile = request.user.userprofile

    if request.method == 'POST':
        form = ProfileEditForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated.')
            return redirect('users:profile_detail', username=request.user.username)
    else:
        form = ProfileEditForm(instance=profile)

    return render(request, 'users/profile_edit.html', {'form': form})
