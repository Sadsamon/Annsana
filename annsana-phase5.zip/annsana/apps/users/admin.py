from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.models import User

from .models import UserProfile


class UserProfileInline(admin.StackedInline):
    model = UserProfile
    can_delete = False
    fk_name = 'user'
    extra = 0


class CustomUserAdmin(UserAdmin):
    inlines = (UserProfileInline,)
    list_display = UserAdmin.list_display + ('get_is_griot',)

    @admin.display(boolean=True, description='Griot')
    def get_is_griot(self, obj):
        return obj.userprofile.is_griot


# Re-register User with the profile inline so Griot promotion (TSD §12:
# "Manual: Django superuser sets userprofile.is_griot = True via admin")
# happens from the same screen as everything else about a user.
admin.site.unregister(User)
admin.site.register(User, CustomUserAdmin)
