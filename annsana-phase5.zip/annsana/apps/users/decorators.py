"""
User-level permission decorators for the Annsana project.

Placed in apps.users because Griot status is a property of UserProfile,
not of any individual app's domain logic.
"""
from functools import wraps

from django.contrib.auth.views import redirect_to_login
from django.core.exceptions import PermissionDenied


def griot_required(view_func):
    """
    Allow access only to authenticated Griots (userprofile.is_griot=True)
    and Django staff/superusers.

    - Unauthenticated → redirect_to_login (honours LOGIN_URL, adds ?next=)
    - Authenticated but not Griot/staff → 403 PermissionDenied
    """
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect_to_login(request.get_full_path())

        if not (
            request.user.is_staff
            or request.user.is_superuser
            or request.user.userprofile.is_griot
        ):
            raise PermissionDenied

        return view_func(request, *args, **kwargs)

    return _wrapped
