from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver

from .models import UserProfile


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_user_profile(sender, instance, created, **kwargs):
    """
    Every auth.User gets exactly one UserProfile. Keeps the OneToOne
    invariant (TSD §5.1) true without requiring every code path that
    creates a User to remember to also create a UserProfile.
    """
    if created:
        UserProfile.objects.create(user=instance)
