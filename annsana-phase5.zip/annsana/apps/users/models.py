from django.conf import settings
from django.db import models


class UserProfile(models.Model):
    """
    One-to-one extension of django.contrib.auth.User.

    Schema per TSD §5.1 (users_userprofile). Standard auth.User is used
    deliberately -- no custom user model -- per the TSD's explicit
    architectural decision.
    """

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='userprofile',
    )
    bio = models.TextField(null=True, blank=True)
    avatar = models.ImageField(
        upload_to='avatars/%Y/%m/',
        null=True,
        blank=True,
    )
    is_griot = models.BooleanField(default=False)
    reputation_score = models.IntegerField(default=0)
    location = models.CharField(max_length=100, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'users_userprofile'

    def __str__(self):
        return f'{self.user.username} profile'

    def recalculate_reputation(self):
        """
        Reputation = votes received on entries authored by this user
                   + votes received on links created by this user.

        Auto-promotes to Griot when score >= settings.GRIOT_THRESHOLD (100).
        Deferred import prevents circular imports at module-load time.
        Called by apps.trust.signals after each new Vote is saved.
        """
        from django.conf import settings as django_settings
        from apps.trust.models import Vote

        entry_votes = Vote.objects.filter(entry__author=self.user).count()
        link_votes = Vote.objects.filter(link__created_by=self.user).count()
        self.reputation_score = entry_votes + link_votes

        threshold = getattr(django_settings, 'GRIOT_THRESHOLD', 100)
        if self.reputation_score >= threshold:
            self.is_griot = True

        self.save(update_fields=['reputation_score', 'is_griot'])
