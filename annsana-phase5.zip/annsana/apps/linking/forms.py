from django import forms

from apps.archive.models import ArchiveEntry
from apps.feed.models import Post

from .models import PostArchiveLink


class LinkFromPostForm(forms.Form):
    """Shown on post_detail: pick an Archive Entry to link to this post."""
    post_pk = forms.IntegerField(widget=forms.HiddenInput)
    entry = forms.ModelChoiceField(
        queryset=ArchiveEntry.objects.select_related('category').order_by('title'),
        empty_label='— Select an archive entry —',
        label='Archive entry',
    )

    def clean(self):
        cleaned = super().clean()
        post_pk = cleaned.get('post_pk')
        entry = cleaned.get('entry')
        if post_pk and entry:
            if PostArchiveLink.objects.filter(post_id=post_pk, entry=entry).exists():
                raise forms.ValidationError(
                    'This post is already linked to that archive entry.'
                )
        return cleaned


class LinkFromEntryForm(forms.Form):
    """Shown on entry_detail: pick a Post to link to this entry."""
    entry_pk = forms.IntegerField(widget=forms.HiddenInput)
    post = forms.ModelChoiceField(
        queryset=Post.objects.select_related('user', 'category').order_by('-created_at'),
        empty_label='— Select a post —',
        label='Post',
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Give posts a readable label in the dropdown.
        self.fields['post'].label_from_instance = lambda obj: (
            f'#{obj.pk} by {obj.user.username} — {(obj.caption or "")[:60]}'
        )

    def clean(self):
        cleaned = super().clean()
        entry_pk = cleaned.get('entry_pk')
        post = cleaned.get('post')
        if entry_pk and post:
            if PostArchiveLink.objects.filter(entry_id=entry_pk, post=post).exists():
                raise forms.ValidationError(
                    'This post is already linked to that archive entry.'
                )
        return cleaned
