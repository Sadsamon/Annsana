from django.urls import path
from . import views

app_name = 'linking'

urlpatterns = [
    path('create/',                        views.link_create,        name='link_create'),
    path('<int:pk>/delete/',               views.link_delete,        name='link_delete'),
    path('post/<int:post_pk>/links/',      views.post_links_partial, name='post_links_partial'),
    path('entry/<slug:entry_slug>/links/', views.entry_links_partial,name='entry_links_partial'),
]
