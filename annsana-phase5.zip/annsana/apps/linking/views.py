"""
Linking views — Phase 4: The Bridge.

Any authenticated user may propose a Post ↔ ArchiveEntry link.
Only the creator or staff may remove one.

Both write views are POST-only and HTMX-aware; they return the
refreshed partial so the page updates inline without a full reload.

  source=post   → caller is post_detail   → return _post_archive_links partial
  source=entry  → caller is entry_detail  → return _entry_post_links partial
"""
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render

from apps.archive.models import ArchiveEntry
from apps.feed.models import Post

from .forms import LinkFromEntryForm, LinkFromPostForm
from .models import PostArchiveLink


# ---------------------------------------------------------------------------
# Write views
# ---------------------------------------------------------------------------

@login_required
def link_create(request):
    """POST only. Creates a PostArchiveLink from either side."""
    if request.method != 'POST':
        return redirect('feed:home')

    source = request.POST.get('source', 'post')

    if source == 'post':
        form = LinkFromPostForm(request.POST)
        if form.is_valid():
            post = get_object_or_404(Post, pk=form.cleaned_data['post_pk'])
            entry = form.cleaned_data['entry']
            PostArchiveLink.objects.create(
                post=post, entry=entry, created_by=request.user,
            )
            if request.htmx:
                return _post_links_response(request, post)
            return redirect('feed:post_detail', pk=post.pk)

        # Validation failed — re-render partial with errors.
        post_pk = request.POST.get('post_pk')
        post = get_object_or_404(Post, pk=post_pk) if post_pk else None
        if request.htmx and post:
            return _post_links_response(request, post, form_errors=form)
        return redirect(request.META.get('HTTP_REFERER', '/'))

    else:  # source == 'entry'
        form = LinkFromEntryForm(request.POST)
        if form.is_valid():
            entry = get_object_or_404(ArchiveEntry, pk=form.cleaned_data['entry_pk'])
            post = form.cleaned_data['post']
            PostArchiveLink.objects.create(
                post=post, entry=entry, created_by=request.user,
            )
            if request.htmx:
                return _entry_links_response(request, entry)
            return redirect('archive:entry_detail', slug=entry.slug)

        entry_pk = request.POST.get('entry_pk')
        entry = get_object_or_404(ArchiveEntry, pk=entry_pk) if entry_pk else None
        if request.htmx and entry:
            return _entry_links_response(request, entry, form_errors=form)
        return redirect(request.META.get('HTTP_REFERER', '/'))


@login_required
def link_delete(request, pk):
    """POST only. Creator or staff/superuser may delete."""
    if request.method != 'POST':
        return redirect('feed:home')

    link = get_object_or_404(PostArchiveLink, pk=pk)

    if not (
        request.user == link.created_by
        or request.user.is_staff
        or request.user.is_superuser
    ):
        raise PermissionDenied

    source = request.POST.get('source', 'post')
    post = link.post
    entry = link.entry
    link.delete()

    if request.htmx:
        if source == 'entry':
            return _entry_links_response(request, entry)
        return _post_links_response(request, post)

    if source == 'entry':
        return redirect('archive:entry_detail', slug=entry.slug)
    return redirect('feed:post_detail', pk=post.pk)


# ---------------------------------------------------------------------------
# HTMX refresh endpoints (plain GET — used if the section needs a reload)
# ---------------------------------------------------------------------------

def post_links_partial(request, post_pk):
    post = get_object_or_404(Post, pk=post_pk)
    return _post_links_response(request, post)


def entry_links_partial(request, entry_slug):
    entry = get_object_or_404(ArchiveEntry, slug=entry_slug)
    return _entry_links_response(request, entry)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _post_links_response(request, post, form_errors=None):
    links = list(
        PostArchiveLink.objects
        .filter(post=post)
        .select_related('entry', 'entry__category', 'created_by')
        .order_by('-created_at')
    )
    # Phase 5: which of these links has the current user already voted on?
    voted_link_ids = set()
    if request.user.is_authenticated:
        try:
            from apps.trust.models import Vote
            voted_link_ids = set(
                Vote.objects.filter(voter=request.user, link__in=links)
                .values_list('link_id', flat=True)
            )
        except Exception:
            pass

    form = form_errors or LinkFromPostForm(initial={'post_pk': post.pk})
    form.fields['post_pk'].initial = post.pk
    return render(request, 'linking/_post_archive_links.html', {
        'post': post,
        'links': links,
        'link_form': form,
        'voted_link_ids': voted_link_ids,
    })


def _entry_links_response(request, entry, form_errors=None):
    links = list(
        PostArchiveLink.objects
        .filter(entry=entry)
        .select_related(
            'post', 'post__user', 'post__user__userprofile',
            'post__category', 'created_by',
        )
        .order_by('-created_at')
    )
    # Phase 5: which of these links has the current user already voted on?
    voted_link_ids = set()
    if request.user.is_authenticated:
        try:
            from apps.trust.models import Vote
            voted_link_ids = set(
                Vote.objects.filter(voter=request.user, link__in=links)
                .values_list('link_id', flat=True)
            )
        except Exception:
            pass

    form = form_errors or LinkFromEntryForm(initial={'entry_pk': entry.pk})
    form.fields['entry_pk'].initial = entry.pk
    return render(request, 'linking/_entry_post_links.html', {
        'entry': entry,
        'links': links,
        'link_form': form,
        'voted_link_ids': voted_link_ids,
    })
