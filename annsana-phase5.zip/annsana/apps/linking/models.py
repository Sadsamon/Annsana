from django.conf import settings
from django.db import models


class PostArchiveLink(models.Model):
    """
    The Bridge (TSD §5.4: linking_postarchivelink).

    Associates one Post with one ArchiveEntry. unique_together enforces
    that the same pair cannot be linked twice. Any authenticated user may
    propose a link; Griots verify them (Phase 5 adds the Vote side).

    created_by is SET_NULL so deleting a user account does not cascade-
    destroy cultural link data that other users contributed to.

    is_verified and verification_count are Phase 5 Trust Layer fields
    present in the schema from day one for stability.
    """
    post = models.ForeignKey(
        'feed.Post',
        on_delete=models.CASCADE,
        related_name='archive_links',
    )
    entry = models.ForeignKey(
        'archive.ArchiveEntry',
        on_delete=models.CASCADE,
        related_name='post_links',
    )
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_links',
    )
    is_verified = models.BooleanField(default=False)
    verification_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'linking_postarchivelink'
        unique_together = [('post', 'entry')]
        ordering = ['-created_at']

    def __str__(self):
        return f'Post #{self.post_id} ↔ "{self.entry.title}"'
