from django.contrib import admin
from .models import PostArchiveLink


@admin.register(PostArchiveLink)
class PostArchiveLinkAdmin(admin.ModelAdmin):
    list_display = ('pk', 'post', 'entry', 'created_by',
                    'is_verified', 'verification_count', 'created_at')
    list_filter  = ('is_verified',)
    search_fields = ('post__caption', 'entry__title', 'created_by__username')
    raw_id_fields = ('post', 'entry', 'created_by')
    readonly_fields = ('created_at', 'verification_count')
